package com.mycompany.BookMyHotel;

import static com.mycompany.BookMyHotel.BookMyRoom.triple_occupancy_room;
import java.util.Map;

public class TripleOccupancy {
    
    String typeOfRoom="";
    String occupancy="";
    int amount = 4000;
    
    TripleOccupancy(String typeOfRoom,String occupancy,int amount)
    {
        this.typeOfRoom = typeOfRoom;
        this.occupancy = occupancy;
        this.amount = this.amount+amount;  
    }
    
    
     public static void checkTripleOccupancy(String typeOfRoom, String occupancy, int amount)
    {
        TripleOccupancy triple_occupancy = new TripleOccupancy(typeOfRoom,occupancy,amount);

         Object str="";boolean availability = false;
         for(Map.Entry m:triple_occupancy_room.entrySet()){    
               if(m.getValue().equals(typeOfRoom))
               {
                   str = m.getKey();
                   availability = true;
                   triple_occupancy_room.replace(str,"notAvailable");
                   break;
               }
               else availability = false;

        }  

         if(availability==true)
            System.out.println("Room number : "+str+","+triple_occupancy.typeOfRoom+","+triple_occupancy.occupancy+","+triple_occupancy.amount);
         else System.out.println("Room not available : "+triple_occupancy.typeOfRoom+","+triple_occupancy.occupancy);

    }
    
}
