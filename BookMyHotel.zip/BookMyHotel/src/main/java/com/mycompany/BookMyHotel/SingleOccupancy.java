package com.mycompany.BookMyHotel;

import static com.mycompany.BookMyHotel.BookMyRoom.single_occupancy_room;
import java.util.Map;

public class SingleOccupancy {
    
   
    
    String typeOfRoom="";
    String occupancy="";
    int amount = 2000;
    
    SingleOccupancy(String typeOfRoom,String occupancy,int amount)
    {
        this.typeOfRoom = typeOfRoom;
        this.occupancy = occupancy;
        this.amount = this.amount+amount;
    }
    
    
    public static void checkSingleOccupancy(String typeOfRoom, String occupancy, int amount)
    {
        
                     
        SingleOccupancy single_occupancy = new SingleOccupancy(typeOfRoom,occupancy,amount);


        Object str="";boolean availability = false;
        for(Map.Entry m:single_occupancy_room.entrySet()){    
              if(m.getValue().equals(typeOfRoom))
              {
                  str = m.getKey();
                  availability = true;
                  single_occupancy_room.replace(str,"notAvailable");
                  break;
              }
              else availability = false;

       }

        if(availability==true)
           System.out.println("Room number : "+str+","+single_occupancy.typeOfRoom+","+single_occupancy.occupancy+","+single_occupancy.amount);
        else System.out.println("Room not available : "+single_occupancy.typeOfRoom+","+single_occupancy.occupancy);

    }
    
}
