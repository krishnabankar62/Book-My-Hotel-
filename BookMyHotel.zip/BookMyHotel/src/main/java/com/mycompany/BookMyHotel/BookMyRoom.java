package com.mycompany.BookMyHotel;

import java.util.HashMap;
import java.util.Scanner;

public class BookMyRoom {
    static Scanner sc = new Scanner(System.in);
    static HashMap<Object,String> single_occupancy_room =new HashMap<>(); 
    static HashMap<Object,String> double_occupancy_room =new HashMap<>();
    static HashMap<Object,String> triple_occupancy_room =new HashMap<>();
    static
    {
        single_occupancy_room.put("101,first floor","ac");
        single_occupancy_room.put("201,second floor","ac");
        single_occupancy_room.put("202,second floor","nonAc");
        
        double_occupancy_room.put("102,first floor","ac");
        double_occupancy_room.put("103,first floor","nonAc");
        double_occupancy_room.put("203,second floor","ac");
        
        triple_occupancy_room.put("204,second floor","ac");
    }
    
    
    
    
    ///////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
         while(true)
         {
             System.out.print("select ac/non ac : ");
             String typeOfRoom = sc.next();
             
             if(typeOfRoom.equals("ac"))
             {
                 int amount = 1000;
                 checkRoomAvailability(typeOfRoom,amount);
             }
             else if(typeOfRoom.equals("nonAc"))
             {
                 int amount = 0;
                 checkRoomAvailability(typeOfRoom,amount);
             }
             else
             {
                 System.out.println("you can select only ac or nonAc !");
             }
             
             
             System.out.print("want to check once more say yes : ");
             String repeat = sc.next();
             if(repeat.equals("yes"))
             {;}
             else break;
         }
    }
    ///////////////////////////////////////////////////////////////////////////
    
    
    
    public static void checkRoomAvailability(String typeOfRoom, int amount)
    {
        System.out.print("enter occupancy : ");
        String occupancy = sc.next();
        
        switch(occupancy)
        {
            case "singleOccupancy" : SingleOccupancy.checkSingleOccupancy(typeOfRoom,occupancy,amount);break;
            case "doubleOccupancy" : DoubleOccupancy.checkDoubleOccupancy(typeOfRoom,occupancy,amount);break;
            case "tripleOccupancy" : TripleOccupancy.checkTripleOccupancy(typeOfRoom,occupancy,amount);break;
            default : System.out.println("Invalid Occupancy !");
        }
    }
    
}
