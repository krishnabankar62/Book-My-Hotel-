package com.mycompany.BookMyHotel;

import static com.mycompany.BookMyHotel.BookMyRoom.double_occupancy_room;
import java.util.Map;

public class DoubleOccupancy {


    String typeOfRoom="";
    String occupancy="";
    int amount = 3000;
    
    DoubleOccupancy(String typeOfRoom,String occupancy,int amount)
    {
        this.typeOfRoom = typeOfRoom;
        this.occupancy = occupancy;
        this.amount = this.amount+amount;
    }
    
    
    public static void checkDoubleOccupancy(String typeOfRoom, String occupancy, int amount)
    {
        DoubleOccupancy double_occupancy = new DoubleOccupancy(typeOfRoom,occupancy,amount);

        Object str="";boolean availability = false;
        for(Map.Entry m:double_occupancy_room.entrySet()){    
              if(m.getValue().equals(typeOfRoom))
              {
                  str = m.getKey();
                  availability = true;
                  double_occupancy_room.replace(str,"notAvailable");
                  break;
              }
              else availability = false;

       }  

        if(availability==true)
           System.out.println("Room number : "+str+","+double_occupancy.typeOfRoom+","+double_occupancy.occupancy+","+double_occupancy.amount);
        else System.out.println("Room not available : "+double_occupancy.typeOfRoom+","+double_occupancy.occupancy);

    }
    
    
}
